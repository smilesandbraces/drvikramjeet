Blog Section Starter (plain HTML)
---------------------------------

1. Place **blog.html** in your project root next to index.html.
2. Put all articles inside **/posts/** as individual .html files.
3. In blog.html, duplicate the <article class="feature-card"> block for each new post.
4. Copy *oral-hygiene-importance.html* when writing a new post—replace the title, date, and content.
5. Add a "Blog" link to your nav on other pages (already done in blog.html).
6. Commit & push to GitHub Pages.

Tip: Switch to Markdown & Jekyll later for quicker publishing if needed.
